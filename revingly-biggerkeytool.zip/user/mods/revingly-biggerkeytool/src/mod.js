"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Mod {
    postDBLoad(container) {
        // get database from server
        const databaseServer = container.resolve("DatabaseServer");
        // Get all the in-memory json found in /assets/database
        const tables = databaseServer.getTables();
        tables.templates.items['59fafd4b86f7745ca07e1232']._props.Grids[0]._props.cellsH = 14;
        tables.templates.items['59fafd4b86f7745ca07e1232']._props.Grids[0]._props.cellsV = 14;
    }
}
module.exports = { mod: new Mod() };
//# sourceMappingURL=mod.js.map